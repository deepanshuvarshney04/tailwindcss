/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './**/*.twig',
    '../../../{modules,themes}/custom/**/*.twig'
  ],
  theme: {
    extend: {
    },
  },
  plugins: [],
}
